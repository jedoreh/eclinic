<?php



$conn = mysqli_connect('localhost', 'root', 'Pa55w0rd@1','eclinic');
  

?>