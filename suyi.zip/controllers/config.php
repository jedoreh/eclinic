<?php

require("db.php");


ob_start();
session_start();


?>